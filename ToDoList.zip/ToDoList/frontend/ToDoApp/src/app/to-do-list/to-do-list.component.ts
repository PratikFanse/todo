import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm, FormGroup, FormControl, FormsModule } from '@angular/forms';
import { Task } from '../shared/task/task';
import { HttpService } from '../shared/http.service';
import { User } from '../shared/user.model';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ActiveUser } from '../shared/activeUser/active-user';

@Component({
  selector: 'app-to-do-list',
  templateUrl: './to-do-list.component.html',
  styleUrls: ['./to-do-list.component.css']
})
export class ToDoListComponent implements OnInit {
  tasks:Task[];
  iftaskChanged:Subscription;
  @ViewChild('tf') tlForm: NgForm;
  constructor(private httpService:HttpService, private route:Router) { }


  ngOnInit(): void {
    
    const u:ActiveUser = JSON.parse(sessionStorage.getItem("activeUser"));
    if(u!=null){
    this.httpService.getTasksList().subscribe(data => this.tasks = data);
    this.iftaskChanged= this.httpService.taskChanged.subscribe(
      (data:Task[]) =>{
      this.tasks=data;
    }
    )}else if(!this.httpService.isUserLogin){
      this.route.navigate(['/authentication'])
    }else if(!u.emailStatus){
    this.route.navigate(['/logError'])
    }
   
    

  }
  task:Task
  onClear(){
    this.tlForm.reset();
  }

  onAddTask(form:NgForm){
    const value =  this.tlForm.value
    const id= value.id==="" ?  0:value.id;
    console.log(value.name+ " " + id)
    this.httpService.addToList(value.name, id)   
  }
  onEditTask(id:number){
    console.log(this.tasks[id].taskid)
    this.tlForm.setValue(
      {name:this.tasks[id].task,
      id:this.tasks[id].taskid})
  }

}
