import { Routes, RouterModule } from '@angular/router';

import { NgModule } from '@angular/core';
import { LoginComponent } from './auth/login/login.component';
import { SignupComponent } from './auth/signup/signup.component';
import { ToDoListComponent } from './to-do-list/to-do-list.component';
import { AuthComponent } from './auth/auth.component';

const appRoutes: Routes =[
    {path:"", component:ToDoListComponent, pathMatch:'full'},
    {path:"authentication",component: AuthComponent, children:[
        {path:"signup",component: SignupComponent},
        {path:"",component: LoginComponent}]},
    
    {path:"ToDo",component: ToDoListComponent},
]

@NgModule({
    imports:[RouterModule.forRoot(appRoutes)],
    exports: [RouterModule]
})

export class AppRoutingModule{}