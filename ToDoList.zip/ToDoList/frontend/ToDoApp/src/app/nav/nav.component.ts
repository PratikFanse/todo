import { Component, OnInit } from '@angular/core';
import { HttpService } from '../shared/http.service';
import { Router } from '@angular/router';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  constructor(private httpService:HttpService,private router:Router, private appComponent:AppComponent) { }

  ngOnInit(): void {
    
    if(!this.httpService.isUserLogin()){
      this.appComponent.loginStatus(false);
    }

  }

  onLogout(){
    this.appComponent.loginStatus(false);
    this.httpService.logout();
    this.router.navigate(['/authentication']);
  }
}
