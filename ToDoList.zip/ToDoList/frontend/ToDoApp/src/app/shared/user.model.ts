export class User {
    public name:string; 
    public lastname:string ;
    public birthdate: Date;
    public username:string ;
    public password:string;
    constructor(
        fname:string, 
        lname:string, 
        birthdate: Date,
        email:string, 
        password:string, )
    {   
        this.name=fname;
        this.lastname=lname;
        this.birthdate=birthdate;
        this.username=email;
        this.password=password;
    }
}
