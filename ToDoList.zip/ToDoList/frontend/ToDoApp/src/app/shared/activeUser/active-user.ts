export class ActiveUser {
    
    constructor(
    public id:number,
    public name:string,
    public username:string,
    public accStatus:boolean,
    public emailStatus:boolean,
    public role:string){}
}
