import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActiveUser } from './activeUser/active-user';
import { User } from './user.model';
import { Task } from './task/task';
import { map } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  taskChanged = new Subject<Task[]>();
  userCred:{username:string,password:string}

  constructor(private http:HttpClient) { }

  login(username:string, password:string){
  this.userCred={username,password}
  console.log(this.userCred.username+" "+ this.userCred.password)
    this.http.post<ActiveUser>("http://localhost:8080/authenticate",this.userCred).toPromise().then(
      data => {
        console.log(data.username);
        sessionStorage.setItem("activeUser", JSON.stringify(data))
      }
    )
      
  }

  register(user:User){
    let status= false;
    this.http.post("http://localhost:8080/register",user).subscribe(data=> {status=true})
    return status
  }

  isUserLogin(){
    const user =sessionStorage.getItem("activeUser")
    return user!=null
  }
  
  logout(){
    sessionStorage.removeItem("activeUser")
  }

  addToList(name:string, id:number){
    let tasks:Task[]=[];
    let activeUser:ActiveUser = JSON.parse(sessionStorage.getItem("activeUser"))
    this.http.post<Task[]>("http://localhost:8080/toDoTask",new Task(id,name,"pending",activeUser.id)).pipe(map
    (data =>{
      this.taskChanged.next(data)
      return data
    }
    )).subscribe(
      data=> {tasks=data
      console.log(data[1].userid)}
    )
    return tasks.slice()
  }

  getTasksList(){
    let u:ActiveUser= JSON.parse(sessionStorage.getItem("activeUser"))
    console.log(u.id+"adsfgdasf")
    return this.http.get<Task[]>("http://localhost:8080/toDoTask/"+u.id).pipe(map
    (data => {
      console.log("test")
      this.taskChanged.next(data)
      return data
    }
      ))
      
  }

}
