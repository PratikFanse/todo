import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-log-error',
  templateUrl: './log-error.component.html',
  styleUrls: ['./log-error.component.css']
})
export class LogErrorComponent implements OnInit {

  constructor(private router:Router) {
      setTimeout(() => {
        router.navigate(['/authentication']),3000
      })
   }

  ngOnInit(): void {
  }

}
