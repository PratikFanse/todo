package com.app.toDoApp.auth.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.app.toDoApp.auth.dao.UserDao;
import com.app.toDoApp.auth.model.DAOUser;
import com.app.toDoApp.auth.model.UserDTO;

import javax.mail.internet.InternetAddress;

@Service
public class JwtUserDetailsService implements UserDetailsService {

	@Autowired
	private UserDao userDao;

	@Autowired
	private PasswordEncoder bcryptEncoder;

	@Autowired
	private JavaMailSender javaMailSender;

	void sendEmail(String name, String username, boolean forVerify) {

		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo(username);
//		try {
//		InternetAddress validate = new InternetAddress(username);
//			validate.validate();
//			System.out.println("Exist");
//		} catch (Exception i){
//			System.err.println("Email is not exist");
//		}
		if(forVerify) {
			msg.setSubject("ToDoApp Email Verifictaion");
			msg.setText("Hello " + name + ", Please verify your email by clicking following link:- " + "http://localhost:8080/emailVerification/"+username);

			javaMailSender.send(msg);
		}else{
			msg.setSubject("ToDoApp Email Verifictaion");
			msg.setText("Hello " + name + ", Your Verification done Successfully..");
			javaMailSender.send(msg);
		}
	}

	public void emailVerified(String email){
		DAOUser user = userDao.findByUsername(email);
		sendEmail(user.getName(),user.getUsername(),false);
		user.setEmailstatus(true);
		userDao.save(user);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		DAOUser user = userDao.findByUsername(username);
		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
				new ArrayList<>());
	}
	public int loadUserIdByUsername(String username){
		System.out.println("Test"+ username);
		DAOUser user= userDao.findByUsername(username);
		System.out.println(user);
		return userDao.findByUsername(username).getId();
	}
	public DAOUser save(DAOUser user) {
		return userDao.save(user);
	}

	public DAOUser save(UserDTO user) {
		sendEmail(user.getName(),user.getUsername(),true);
		DAOUser newUser = new DAOUser();
		newUser.setName(user.getName());
		newUser.setLastname(user.getLastname());
		newUser.setBirthdate(user.getBirthdate());
		newUser.setUsername(user.getUsername());
		newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
		newUser.setEmailstatus(false);
		newUser.setAccstatus(false);
		newUser.setRole("user");
//		sendVerificationEmail(user.getUsername());
		return userDao.save(newUser);
	}

//	public void sendVerificationEmail(String email) {
//		String encryptedString = AES.encrypt(email) ;
//	}
}